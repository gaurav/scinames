# taxonomy-archive
Monthly snapshots of [AmphibiaWeb](http://amphibiaweb.org)'s working taxonomy as text files.

Read about AmphibiaWeb's Taxonomy here: http://amphibiaweb.org/taxonomy/index.html where you can download the daily snapshot here: http://amphibiaweb.org/amphib_names.txt

We have a Family Tree visualization here:
http://amphibiaweb.org:8000/taxonomy/amphibia_familytree_sum_v3.png

Please contact amphibiaweb@berkeley.edu with any comments or questions.

 - CC-BY: Attribution
